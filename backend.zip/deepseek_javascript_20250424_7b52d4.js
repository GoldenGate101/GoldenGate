const mongoose = require('mongoose');

const contentSchema = new mongoose.Schema({
  section: { type: String, required: true }, // e.g., "hero", "about"
  key: { type: String, required: true },    // e.g., "title", "description"
  value: { type: String, required: true }   // Actual content text
});

module.exports = mongoose.model('Content', contentSchema);
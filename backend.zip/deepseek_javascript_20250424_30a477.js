const Content = require('../models/Content');

// Get all content
exports.getContent = async (req, res) => {
  try {
    const content = await Content.find();
    res.json(content);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Update content
exports.updateContent = async (req, res) => {
  try {
    const { section, key, value } = req.body;
    let content = await Content.findOneAndUpdate(
      { section, key },
      { value },
      { new: true, upsert: true }
    );
    res.json(content);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};